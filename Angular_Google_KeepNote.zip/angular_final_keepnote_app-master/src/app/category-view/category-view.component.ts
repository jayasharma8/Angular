import { Component, OnInit } from '@angular/core';
import { Category } from '../category';

import { CategoryService } from '../services/category.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-category-view',
  templateUrl: './category-view.component.html',
  styleUrls: ['./category-view.component.css']
})
export class CategoryViewComponent implements OnInit {

  categories: Array<Category>;
  category: Category = new Category();

  constructor(private categoryService:CategoryService, private authservice:AuthenticationService) {
    this.categories=[];
   }

  ngOnInit() {
    if(this.authservice.getBearerToken!=null || this.authservice){
    this.categoryService.getCategory().subscribe(
      data => this.categories = data,
      err => console.log(err)
    );
  }
  }
}
