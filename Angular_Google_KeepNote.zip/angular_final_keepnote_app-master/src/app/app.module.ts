import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { AuthenticationService } from './services/authentication.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatIconModule} from '@angular/material';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { RouterService } from './services/router.service';
import { NoteComponent } from './note/note.component';
import { NotesService} from './services/notes.service';
import { NoteTakerComponent } from './note-taker/note-taker.component';
import { NoteViewComponent } from './note-view/note-view.component';
import { ListViewComponent } from './list-view/list-view.component';
import { EditNoteViewComponent } from './edit-note-view/edit-note-view.component';
import { EditNoteOpenerComponent } from './edit-note-opener/edit-note-opener.component';
import { CanActivateRouteGuard } from './can-activate-route.guard';
import { CategoryComponent } from './category/category.component';
import { CategoryTakerComponent } from './category-taker/category-taker.component';
import { CategoryViewComponent } from './category-view/category-view.component';
import { CategoryService} from './services/category.service';
import { EditCategoryOpenerComponent } from './edit-category-opener/edit-category-opener.component';
import { EditCategoryViewComponent } from './edit-category-view/edit-category-view.component';
import { NoteNavComponent } from './note-nav/note-nav.component';
import {MatTabsModule} from '@angular/material/tabs';
import { CategoryNavComponent } from './category-nav/category-nav.component';
import { ReminderComponent } from './reminder/reminder.component';
import { ReminderNavComponent } from './reminder-nav/reminder-nav.component';
import { ReminderTakerComponent } from './reminder-taker/reminder-taker.component';
import { ReminderViewComponent } from './reminder-view/reminder-view.component';
import { EditReminderOpenerComponent } from './edit-reminder-opener/edit-reminder-opener.component';
import { EditReminderViewComponent } from './edit-reminder-view/edit-reminder-view.component';
import {ReminderService} from './services/reminder.service';
import { RegisterUserComponent } from './register-user/register-user.component';
import { UserService } from './services/user.service';
import { EditUserComponent } from './edit-user/edit-user.component';
import {AddNoteCategoryComponent} from './add-note-category/add-note-category.component';
import { AddNoteReminderComponent } from './add-note-reminder/add-note-reminder.component';

const appRoutes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent },
  { path: 'registeruser', component: RegisterUserComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [CanActivateRouteGuard],
    children: [
      { path: 'edituser', component: EditUserComponent },
      {path: '', redirectTo: 'noteNav', pathMatch: 'full'},
     { path: 'noteNav', component:NoteNavComponent,
      children: [
        {
          path: 'view/noteview', component: NoteViewComponent
      },
      {
        path: 'view/listview', component: ListViewComponent
      },
      {
        path: '', redirectTo: 'view/noteview', pathMatch: 'full'
      },
      {
        path: 'note/:noteId/edit', component: EditNoteOpenerComponent, outlet: 'noteEditOutlet'
      }
      ]
    },

    { path: 'categoryNav', component:CategoryNavComponent,
    children: [
      {
        path: 'view/categoryview', component: CategoryViewComponent
    },
    {
      path: '', redirectTo: 'view/categoryview', pathMatch: 'full'
    },
    {
      path: 'category/:categoryId/edit', component: EditCategoryOpenerComponent, outlet: 'categoryEditOutlet'
    }
    ]
  } ,
   { path: 'reminderNav', component:ReminderNavComponent,
    children: [
      {
        path: 'view/reminderview', component: ReminderViewComponent
    },
    {
      path: '', redirectTo: 'view/reminderview', pathMatch: 'full'
    },
    {
      path: 'reminder/:reminderId/edit', component: EditReminderOpenerComponent, outlet: 'reminderEditOutlet'
    }
    ]
  }
   ]
  }
];

@NgModule({
  declarations: [
    AppComponent,
	LoginComponent,
    HeaderComponent,
	DashboardComponent,
    NoteComponent,
    NoteTakerComponent,
    NoteViewComponent,
    ListViewComponent,
	EditNoteViewComponent,
    EditNoteOpenerComponent,
    CategoryComponent,
    CategoryTakerComponent,
    CategoryViewComponent,
    EditCategoryOpenerComponent,
    EditCategoryViewComponent,
    NoteNavComponent,
    CategoryNavComponent,
    ReminderComponent,
    ReminderNavComponent,
    ReminderTakerComponent,
    ReminderViewComponent,
    EditReminderOpenerComponent,
    EditReminderViewComponent,
    RegisterUserComponent,
    EditUserComponent,
    AddNoteCategoryComponent,
    AddNoteReminderComponent 
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatCardModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSelectModule,
    HttpClientModule,
    MatTabsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    AuthenticationService,RouterService,NotesService, CategoryService,ReminderService, UserService, CanActivateRouteGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [ 
    EditNoteViewComponent,
    AddNoteCategoryComponent,
    EditCategoryViewComponent,
    EditReminderViewComponent,
    AddNoteReminderComponent]
})

export class AppModule { }
