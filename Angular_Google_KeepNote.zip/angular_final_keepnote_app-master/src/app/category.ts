export class Category {
    categoryId: string;
    categoryName: string;
    categoryDescription: string;
    categoryCreationDate: string;
    categoryCreatedBy: string
  
    constructor() {
      this.categoryName = '';
      this.categoryDescription = '';
      //this.categoryId = '';
    }
  }