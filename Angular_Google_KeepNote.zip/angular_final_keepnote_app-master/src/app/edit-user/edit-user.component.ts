import { Component, OnInit } from '@angular/core';
import {User} from '../user';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { UserService } from '../services/user.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  //user: User;
  options: FormGroup;
  hide=true;
  user: User = new User();
  userId = new FormControl();
  userPassword = new FormControl();
  firstName= new FormControl();
  lastName= new FormControl();
  mobileNo=new FormControl();
  bearerToken: any;
  submitMessage: String;
  formValidation:String;
  regMessage:string;
  edituserForm;

  constructor(private routeService: RouterService,private authservice:AuthenticationService,
    private userservice:UserService) { 
    //  this.firstName=this.user.firstName;
   
    }

  ngOnInit() {
    this.edituserForm = new FormGroup({ firstName: new FormControl('', [Validators.required]),    
    lastName: new FormControl('', [Validators.required]),
   userId: new FormControl('', [Validators.required]),
   userPassword: new FormControl('', [Validators.required, Validators.minLength(4)]),
   mobileNo: new FormControl('', [Validators.required])
}); 

if(this.authservice.getBearerToken()!=null && this.authservice.getBearerToken()!=''){
  this.edituserForm.controls['userId'].disable();
  this.userservice.fetchUserById(this.authservice.getUserId()).subscribe(user => {
    this.user = user;
  }, (err: any) => {
   console.log("Error");
  });;
}
else{
  this.routeService.routeToLogin();
}
  }
 
  editUser(user: User) {
    this.userservice.doUpdate(user).subscribe(response => {

      this.routeService.routeToEditUser();
      this.regMessage = " User profile is updated .";
    }
    , error => {
      if(error.status == 409) {
        this.submitMessage = "Error while updating user";
      }
      else{
        console.log(" User details are updated. "+this.submitMessage );
      }  
    })
  }
}
