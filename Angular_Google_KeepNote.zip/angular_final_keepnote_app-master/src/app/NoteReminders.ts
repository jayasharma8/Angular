export class NoteReminders {
   reminderId: string;
    reminderName: string;
}