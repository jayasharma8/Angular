import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  isNoteView = true;
  iscategoryView=true;
  isReminderView=true;
  isEditView=true;

  constructor(private location: Location, private router: Router, private routerService: RouterService) {
    router.events.subscribe((val) => {
      if (location.path().indexOf('listview') > -1) {
        this.isNoteView = false;
      } else {
        this.isNoteView = true;
      }
    });
    router.events.subscribe((val) => {
      if (location.path().indexOf('listview') > -1) {
        this.iscategoryView = false;
      } else {
        this.iscategoryView = true;
      }
    });

  }

  changeDisplayView() {
    if (this.isNoteView) {
      this.routerService.routeToListView();
      this.isNoteView = false;
    } else {
      this.routerService.routeToNoteView();
      this.isNoteView = true;
    }
  }
  
  changeDisplayCatView() {
    if (this.iscategoryView) {
      this.routerService.routeToCategoryView();
      this.iscategoryView = false;
    } else {
      this.routerService.routeToCategoryView();
      this.iscategoryView = true;
    }
  }

  changeDisplayReminderView() {
    if (this.isReminderView) {
      this.routerService.routeToReminderView();
      this.isReminderView = false;
    } else {
      this.routerService.routeToReminderView();
      this.isReminderView = true;
    }
  }

  changeDisplayEditView() {
    if (this.isEditView) {
      this.routerService.routeToEditUser();
      this.isEditView = false;
    } else {
      this.routerService.routeToEditUser();
      this.isEditView = true;
    }
  }
 
}
