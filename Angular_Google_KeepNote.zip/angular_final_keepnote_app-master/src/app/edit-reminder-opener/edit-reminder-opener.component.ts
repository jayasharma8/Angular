import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { EditReminderViewComponent } from '../edit-reminder-view/edit-reminder-view.component';
import {ActivatedRoute} from '@angular/router';
import {RouterService} from '../services/router.service';

@Component({
  selector: 'app-edit-reminder-opener',
  templateUrl: './edit-reminder-opener.component.html',
  styleUrls: ['./edit-reminder-opener.component.css']
})
export class EditReminderOpenerComponent {

 //constructor() { }

  constructor(private dialog: MatDialog, private activateRoute: ActivatedRoute, private routerService: RouterService) {

    const reminderId = +this.activateRoute.snapshot.paramMap.get('reminderId');
    console.log('this is the card index : ' + reminderId);
    this.dialog.open(EditReminderViewComponent, {
      data: {
        reminderId : reminderId
      }
    }).afterClosed().subscribe(result => {
      this.routerService.routeBack();
    });
   }

}
