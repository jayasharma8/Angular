import { Component, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Note } from '../note';
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  // note: Note = new Note(); // to create note object
  // notes: Array<Note> = []; // to declare notes array

  constructor(private http: HttpClient, private routerservice:RouterService, private authservice:AuthenticationService) {
    //this.notesService.fetchNotesFromServer();
  }

    logout(){
      this.authservice.logout();
      this.routerservice.routeToLogin();
     }

 
}
