import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
     hide=true;
    userId = new FormControl();
    userPassword = new FormControl();
    bearerToken: any;
    submitMessage: String;
    loginForm;

    constructor(private authService: AuthenticationService, private routerService: RouterService) { }

    ngOnInit() {
      this.loginForm = new FormGroup({
        userId: new FormControl('', [Validators.required]),
        userPassword: new FormControl('', [Validators.required, Validators.minLength(4)])
      });

    //  this.authService.logout();
      
    }

    get loginF() { return this.loginForm.controls; }

    loginSubmit() {
 
    if(this.loginForm.value.userId!=null && this.loginForm.value.userId!='' && this.loginForm.value.userPassword &&this.loginForm.value.userPassword){
      this.authService.authenticateUser(this.loginForm.value).subscribe(
        res => {
          this.bearerToken = res['token'];
          this.authService.setBearerToken(this.bearerToken);
          this.authService.saveUserId(this.loginForm.get('userId').value);
          this.routerService.routeToDashboard();
        },
        err => {
          if (err.status === 404) {
            this.submitMessage = `Http failure response for ${err.url}: 404 Not Found`;
            console.log(" submitMessage error" + this.submitMessage );
          } else {
            this.submitMessage = err.error.message;
            console.log(" submitMessage error" + this.submitMessage );
          }
        }
      );
    } 
    else{
      this.routerService.routeToLogin();
    } 
  }
}
