import { Component, OnInit,Inject } from '@angular/core';
import { Note } from '../note';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterService } from '../services/router.service';
import { NotesService } from '../services/notes.service';
import { NoteReminders } from '../NoteReminders';
import { AuthenticationService } from '../services/authentication.service';
import { ReminderService } from '../services/reminder.service';
import { Reminder } from '../reminder';

@Component({
  selector: 'app-add-note-reminder',
  templateUrl: './add-note-reminder.component.html',
  styleUrls: ['./add-note-reminder.component.css']
})
export class AddNoteReminderComponent implements OnInit {

  note:Note;
  reminderArray:Array<NoteReminders>;
  userReminder: Array<Reminder>;
  remArray: Array<Reminder>;
  remObj:Reminder=new Reminder();
  errMessage: string;
 
  constructor(private matDialogRef: MatDialogRef<AddNoteReminderComponent>,
    private routeService: RouterService,
    private authService: AuthenticationService,
    private notesService: NotesService,
    private reminderService:ReminderService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private location: Location) { 
      console.log('in constructor');
      this.note=this.data.reminderInfo;
      this.remArray = [];
      this.userReminder = [];
      this.reminderArray =[];
    }

  ngOnInit() {
    console.log('in init');
    this.reminderService.fetchNoteRemindersFromServer().subscribe(remindersValue => {
        console.log('success');
      this.userReminder = remindersValue;
      for(const remin of this.userReminder) {
        if(remin.reminderCreatedBy === this.authService.getUserId()) {
          this.remArray.push(remin);
        }
      }
      let con;
    for(const rem1 of this.remArray) {
      console.log('came inside loop');
      con = new NoteReminders();
      con.reminderId = rem1.reminderId;
      con.reminderName = rem1.reminderName;
      this.reminderArray.push(con);

    }

    }, (err: any) => {
      console.log('came to error');
    });
 }
  onRemChange(event){
    console.log("event---"+ event);

    for(const cat of this.userReminder) {
      if(event===cat.reminderId) {
        //this.catObj=cat;
        this.note.reminder.push(cat);
      }
    }
  }
  onReminderSave(){
    this.notesService.editNote(this.note).subscribe(
      editedNote => {
      this.matDialogRef.close();
      },
      err => {
       this.errMessage = err.message;
        
      }  
    );

  }

}
