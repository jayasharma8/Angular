import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNoteReminderComponent } from './add-note-reminder.component';

describe('AddNoteReminderComponent', () => {
  let component: AddNoteReminderComponent;
  let fixture: ComponentFixture<AddNoteReminderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddNoteReminderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNoteReminderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
