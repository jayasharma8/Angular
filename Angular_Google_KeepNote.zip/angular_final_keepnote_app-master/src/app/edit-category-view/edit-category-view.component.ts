import { Component, OnInit , Inject, OnDestroy} from '@angular/core';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Category } from '../category';

import { RouterService } from '../services/router.service';
import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-edit-category-view',
  templateUrl: './edit-category-view.component.html',
  styleUrls: ['./edit-category-view.component.css']
})
export class EditCategoryViewComponent implements OnInit {
  category:Category;
  errMessage: string;

  //constructor() { }
  constructor(private matDialogRef: MatDialogRef<EditCategoryViewComponent>,
    private routeService: RouterService,
    private categoryService: CategoryService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private location: Location) { }

  ngOnInit() {
    console.log('Edit category ID ' + this.data.categoryId);
    this.category = this.categoryService.getCategoryById(this.data.categoryId);
  }

  onSaveCategory() {
    this.categoryService.editCategory(this.category).subscribe(
      editedCategory => {
      this.matDialogRef.close();
      },
      err => {
       this.errMessage = err.message;
        
      }  
    );
  }

}
