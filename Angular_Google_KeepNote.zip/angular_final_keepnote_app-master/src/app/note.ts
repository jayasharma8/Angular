import { Reminder } from "./reminder";
import { Category } from "./category";

export class Note {
  noteId: Number;
  noteTitle: string;
  noteContent: string;
  noteStatus: string;
  noteCreatedBy: string;
  category:Category;
  reminder:Array<Reminder>;
  constructor() {
    this.noteTitle = '';
    this.noteContent = '';
  //  this.createdBy = '';
    this.noteStatus = 'not-started';
  }
}