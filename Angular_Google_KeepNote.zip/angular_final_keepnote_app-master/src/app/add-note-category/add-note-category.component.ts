import { Component, OnInit,Inject } from '@angular/core';
import { Note } from '../note';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterService } from '../services/router.service';
import { NotesService } from '../services/notes.service';
import { CategoryService } from '../services/category.service';
import { Category } from '../category';
import { NoteCategory } from '../NoteCategory';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-add-note-category',
  templateUrl: './add-note-category.component.html',
  styleUrls: ['./add-note-category.component.css']
})
export class AddNoteCategoryComponent implements OnInit {
  note:Note;
  categoryArray:Array<NoteCategory>;
  userCategory: Array<Category>;
  catArray: Array<Category>;
  catObj:Category=new Category();

  errMessage: string;
  constructor(private matDialogRef: MatDialogRef<AddNoteCategoryComponent>,
    private routeService: RouterService,
    private authService: AuthenticationService,
    private notesService: NotesService, private categoryservice:CategoryService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private location: Location) { 
      console.log('in constructor');
      this.note=this.data.noteInfo;
      this.catArray = [];
      this.userCategory = [];
      this.categoryArray =[];
     

    }

  ngOnInit() {

    console.log('in init');
    this.categoryservice.fetchCategoriesForNotesFromServer().subscribe(categories => {
        console.log('success');
      this.userCategory = categories;
      for(const cat of this.userCategory) {
        if(cat.categoryCreatedBy === this.authService.getUserId()) {
          this.catArray.push(cat);
        }
      }
      let con;
    for(const cat1 of this.catArray) {
      console.log('came inside loop');
      con = new NoteCategory();
      con.categoryId = cat1.categoryId;
      con.categoryName = cat1.categoryName;
      this.categoryArray.push(con);

    }

    }, (err: any) => {
      console.log('came to error');
    });
    
  }
  onCatChange(event){

    console.log("event---"+ event);

    for(const cat of this.userCategory) {
      if(event===cat.categoryId) {
        //this.catObj=cat;
        this.note.category=cat;
      }
    }
  }
  onCategorySave(){
    this.notesService.editNote(this.note).subscribe(
      editedNote => {
      this.matDialogRef.close();
      },
      err => {
       this.errMessage = err.message;
        
      }  
    );

  }

}
