import { Injectable } from '@angular/core';
import { Router} from '@angular/router';
import { Location } from '@angular/common';

@Injectable()
export class RouterService {

  constructor(private router: Router, private location: Location) { }

  routeToDashboard() {
    this.router.navigate(['dashboard']);
  }

  routeToLogin() {
    this.router.navigate(['login']);
  }
  
  routeToNoteNav() {
    this.router.navigate(['dashboard/noteNav']);
  }
  routeToEditNoteView(noteId) {
    this.router.navigate([
      'dashboard/noteNav',
      {
        outlets : {
          noteEditOutlet: [ 'note', noteId, 'edit' ]
        }
      }
    ]);
  }

  // routeToEditNoteCategoryView(categoryId) {
  //   this.router.navigate([
  //     'dashboard/addnotecategory',
  //     {
  //       outlets : {
  //        reminderEditOutlet: [ 'category', categoryId, 'edit' ]
  //       }
  //     }
  //   ]);
  // }

  routeToEditCategoryView(categoryId) {
    this.router.navigate([
      'dashboard/categoryNav',
      {
        outlets : {
          categoryEditOutlet: [ 'category', categoryId, 'edit' ]
        }
      }
    ]);
  }
  routeToEditReminderView(reminderId) {
    this.router.navigate([
      'dashboard/reminderNav',
      {
        outlets : {
         reminderEditOutlet: [ 'reminder', reminderId, 'edit' ]
        }
      }
    ]);
  }
  routeBack() {
    this.location.back();
  }

  routeToNoteView() {
    this.router.navigate(['dashboard/view/noteview']);
  }
  

  routeToListView() {
    this.router.navigate(['dashboard/view/listview']);
  }
  routeToCategoryView() {
    this.router.navigate(['view/categoryview']);
  }
  routeToReminderView() {
    this.router.navigate(['view/reminderview']);
  }
  routeToEditUser(){
    this.router.navigate(['dashboard/edituser']);
  }


}
