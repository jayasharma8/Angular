import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Category } from '../category';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/do';

import { AuthenticationService } from '../services/authentication.service';


@Injectable()
export class CategoryService {

  categories: Array<Category>;
  userCategory:Array<Category>;
  categorySubject: BehaviorSubject<Array<Category>>;

  constructor(private http: HttpClient, private authService: AuthenticationService) {
    this.categories = [];
    this.userCategory=[];
    this.categorySubject = new BehaviorSubject([]);
  }

  fetchCategoriesFromServer() {
    
    return this.http.get<Array<Category>>(`http://localhost:8083/api/v1/category`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).subscribe(categories => {
      this.userCategory.splice(0, this.userCategory.length);
      this.categories.splice(0, this.categories.length);
      
      this.userCategory = categories;
      for(const cat of this.userCategory) {
        if(cat.categoryCreatedBy === this.authService.getUserId())
        this.categories.push(cat);

      }
      this.categorySubject.next(this.categories);
      console.log('categories = ' + this.categories);
    }, (err: any) => {
      this.categorySubject.error(err);
    });
  }

  fetchCategoriesForNotesFromServer(): Observable<Category[]>{
    console.log('in service');
    
    return this.http.get<Array<Category>>(`http://localhost:8083/api/v1/category`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
    
  }

  getCategory(): BehaviorSubject<Array<Category>> {
    return this.categorySubject;
  }

  addCategory(category: Category): Observable<Category> {
    category.categoryCreatedBy = this.authService.getUserId();
    console.log(" category object        "+ category.categoryId);
    return this.http.post<Category>(`http://localhost:8083/api/v1/category`, category, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(addedCategory => {
     this.categorySubject.next(this.categories);
    });
  }

  editCategory(category: Category): Observable<Category> {
    return this.http.put<Category>(`http://localhost:8083/api/v1/category/${category.categoryId}`, category, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(editedCategory => {
      const oldCategory = this.categories.find( catValue => catValue.categoryId === category.categoryId);
      Object.assign(oldCategory, category);
      this.categorySubject.next(this.categories);
    });
  }

  // editNoteCategory(category: Category): Observable<Category> {
  //   return this.http.put<Category>(`http://localhost:8083/api/v1/category/${category.categoryId}`, category, {
  //     headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
  //   }).do(editedCategory => {
  //     const oldCategory = this.categories.find( catValue => catValue.categoryId === category.categoryId);
  //     Object.assign(oldCategory, category);
  //     this.categorySubject.next(this.categories);
  //   });
  // }



  deleteCategory(category:Category): Observable<Object>{
    console.log("getUserId ---" + this.authService.getUserId());
    console.log("CategoryId ---" + category.categoryId);  
   return this.http.delete(`http://localhost:8083/api/v1/category/${category.categoryId}`,
  //  {headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)}
  {
    headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
  }
   
   );
  }
  getCategoryById(categoryId): Category {
    this.fetchCategoriesFromServer();
    const category = this.categories.find( categoryValue =>categoryValue.categoryId == categoryId);
    return Object.assign({}, category);
  }
  }
