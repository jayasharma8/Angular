import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Reminder } from '../reminder';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/do';

import { AuthenticationService } from '../services/authentication.service';


@Injectable()
export class ReminderService {

  reminders: Array<Reminder>;
  reminderSubject: BehaviorSubject<Array<Reminder>>;
  userReminder:Array<Reminder>;
  //categorySubject: BehaviorSubject<Array<Reminder>>;

  constructor(private http: HttpClient, private authService: AuthenticationService) {
    this.reminders = [];
    this.reminderSubject = new BehaviorSubject([]);
    this.userReminder=[];
  }

  fetchRemindersFromServer() {
    return this.http.get<Array<Reminder>>(`http://localhost:8086/api/v1/reminder`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).subscribe(categories => {
      this.userReminder.splice(0, this.userReminder.length);
      this.reminders.splice(0, this.reminders.length);
      
      this.userReminder = categories;
      for(const cat of this.userReminder) {
        if(cat.reminderCreatedBy === this.authService.getUserId())
        this.reminders.push(cat);

      }
      this.reminderSubject.next(this.reminders);
      console.log('reminders = ' + this.reminders);
    }, (err: any) => {
      this.reminderSubject.error(err);
    });
  }

  fetchNoteRemindersFromServer(): Observable<Reminder[]>{
    console.log('in service');
    
    return this.http.get<Array<Reminder>>(`http://localhost:8086/api/v1/reminder`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
    
  }

  getReminder(): BehaviorSubject<Array<Reminder>> {
    return this.reminderSubject;
  }

  addReminder(reminder: Reminder): Observable<Reminder> {
    reminder.reminderCreatedBy = this.authService.getUserId();
    console.log(" reminder object        "+ reminder.reminderId);
    return this.http.post<Reminder>(`http://localhost:8086/api/v1/reminder`, reminder, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(addedReminder => {
     this.reminderSubject.next(this.reminders);
    });
  }

  editReminder(reminder: Reminder): Observable<Reminder> {
    return this.http.put<Reminder>(`http://localhost:8086/api/v1/reminder/${reminder.reminderId}`, reminder, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(editedReminder => {
      const oldReminder = this.reminders.find( remValue => remValue.reminderId === reminder.reminderId);
      Object.assign(oldReminder, reminder);
      this.reminderSubject.next(this.reminders);
    });
  }


  deleteReminder(reminder: Reminder): Observable<Object>{
    console.log("getUserId ---" + this.authService.getUserId());
    console.log("reminder Id ---" + reminder.reminderId);  
   return this.http.delete(`http://localhost:8086/api/v1/reminder/${reminder.reminderId}`,
  //  {headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)}
  {
    headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
  }
   
   );
  }
  getReminderById(reminderId): Reminder {
    this.fetchRemindersFromServer();
    const reminder = this.reminders.find( reminderValue =>reminderValue.reminderId == reminderId);
    return Object.assign({}, reminder);
  }
  }
