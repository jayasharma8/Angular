import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {User} from '../user';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class UserService {
  user: User;
  userSubject: BehaviorSubject<Array<User>>;

  constructor(private http: HttpClient, private authService:AuthenticationService) {

  }

  doRegister(user: User): Observable<Object> {
    
    return this.http.post('http://localhost:8089/api/v1/auth/register', user);
  }
 
  fetchUserById(uName) {
   
      return this.http.get<User>(`http://localhost:8089/api/v1/auth/user/${this.authService.getUserId()}`, {
        headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
      });
      }

      getCategory(): BehaviorSubject<Array<User>> {
        return this.userSubject;
      }

      
  doUpdate(user: User): Observable<Object> {
    
    return this.http.put(`http://localhost:8089/api/v1/auth/user/update/${this.authService.getUserId()}`, user);
  }

  // doUpdate(user: User): Observable<User> {
  //   return this.http.put<User>(`http://localhost:8089/api/v1/auth/user/${user.userId}`, user, {
  //     headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
  //   }).do(editedCategory => {
  //     const oldCategory = this.user.( catValue => catValue.categoryId === category.categoryId);
  //     Object.assign(oldCategory, category);
  //     this.categorySubject.next(this.categories);
  //   });
  // }
}


