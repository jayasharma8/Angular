import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Note } from '../note';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/do';

import { AuthenticationService } from '../services/authentication.service';
import { Reminder } from '../reminder';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  remArray:Array<Reminder>
  notesSubject: BehaviorSubject<Array<Note>>;
  constructor(private http: HttpClient, private authService: AuthenticationService) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject([]);
  }

  fetchNotesFromServer() {
  
    return this.http.get<Array<Note>>(`http://localhost:8082/api/v1/note/${this.authService.getUserId()}`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).subscribe(notes => {
      this.notes = notes;
      this.notesSubject.next(this.notes);
      console.log('Notes = ' + this.notes);
    }, (err: any) => {
      this.notesSubject.error(err);
    });
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }

  addNote(note: Note): Observable<Note> {
 note.noteCreatedBy = this.authService.getUserId();
 //console.log("createdBy"+note );
    return this.http.post<Note>(`http://localhost:8082/api/v1/note`, note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(addedNote => {
    //  this.notes.push(addedNote);
      this.notesSubject.next(this.notes);
    });
  }

  editNote(note: Note): Observable<Note> {

    console.log(note.reminder);
      return this.http.put<Note>(`http://localhost:8082/api/v1/note/${this.authService.getUserId()}/${note.noteId}`, note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(editedNote => {
      const oldNote = this.notes.find( noteValue => noteValue.noteId === note.noteId);
      Object.assign(oldNote, note);
      this.notesSubject.next(this.notes);
    });
  }


  deleteNote(note:Note): Observable<Object>{
    console.log("getUserId" + this.authService.getUserId());
    console.log("noteId" + note.noteId);  
   return this.http.delete(`http://localhost:8082/api/v1/note/${this.authService.getUserId()}/${note.noteId}`,
  //  {headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)}
  {
    headers: new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
  }
   );
  }

  getNoteById(noteId): Note {
    const note = this.notes.find( noteValue => noteValue.noteId === noteId);
    return Object.assign({}, note);
  }
  }
