import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import { RouterService } from './router.service';

@Injectable()
export class AuthenticationService {
  
  private authUrl: string;
   //private userId = "";

   constructor(private http: HttpClient, private routerservice: RouterService) {
    this.authUrl = 'http://localhost:8089/api/v1/auth/login';
  }
 // private saveUserIdToLocalStorage(userId: string){
  //  localStorage.setItem(this.userId, userId);
  //}
  // private saveAuthtokenToLocalStorage(authToken: string){
  //   localStorage.setItem(this.userAuthToken, authToken);
  // }

  authenticateUser(data) {
    console.log("data---"+ data);
    return this.http.post(`${this.authUrl}`, data);
  }

  setBearerToken(token) {
    localStorage.setItem('bearerToken', token);
  }
  
  getBearerToken() {
    return localStorage.getItem('bearerToken');
  }
  saveUserId(userId){
    localStorage.setItem('userId',userId);
  }
	getUserId(){
    return localStorage.getItem('userId');
  } 
  
  isUserAuthenticated(token): Promise<boolean> {
    return this.http.post(`${this.authUrl}`, {}, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    })
    .map((res) => res['isAuthenticated'])
    .toPromise();
  }

logout() {
  // remove user from local storage to log user out
  // localStorage.removeItem('bearerToken');
  // localStorage.removeItem('userId');
  this.saveUserId('');
  this.setBearerToken('');
}
    //   isRegistered(){
    //     localStorage.setItem('regmessage','Registration successful')
    // } 

}
