export class Reminder {
    reminderId: string;
    reminderName: string;
    reminderDescription: string;
    reminderCreationDate: string;
    reminderCreatedBy: string
  
    constructor() {
      this.reminderName = '';
      this.reminderDescription = '';
    }
  }
