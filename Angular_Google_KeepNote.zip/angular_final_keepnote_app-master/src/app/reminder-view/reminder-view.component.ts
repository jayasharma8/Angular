import { Component, OnInit } from '@angular/core';
import { Reminder } from '../reminder';
import { ReminderService } from '../services/reminder.service';

@Component({
  selector: 'app-reminder-view',
  templateUrl: './reminder-view.component.html',
  styleUrls: ['./reminder-view.component.css']
})
export class ReminderViewComponent implements OnInit {

  reminders: Array<Reminder>;
  reminder: Reminder = new Reminder();

  constructor(private reminderService:ReminderService) {
    this.reminders=[];
   }

  ngOnInit() {

    this.reminderService.getReminder().subscribe(
      data => this.reminders = data,
      err => console.log(err)
    );
  }

}
