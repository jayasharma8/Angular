import { Component, OnInit,Input } from '@angular/core';
import { Category} from '../category';
import { RouterService } from '../services/router.service';
import {CategoryService} from '../services/category.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  errMessage: string;

  @Input() category: Category;

  constructor(private routerService: RouterService, private categoryService: CategoryService) { }

  ngOnInit() {
  }
  openEditCtgryView() {
    console.log(this.category.categoryId);
    this.routerService.routeToEditCategoryView(this.category.categoryId);
  }

deleteCategory() {
  this.categoryService.deleteCategory(this.category).subscribe(
    deleteCategory => {
      const arrayIdx:number = this.categoryService.categories.findIndex( categoryValue => categoryValue.categoryId === this.category.categoryId);
      console.log("arrayIdx "+arrayIdx);
      this.categoryService.categories.splice(arrayIdx,1);
     this.categoryService.categorySubject.next(this.categoryService.categories);
    },
    err => {
     this.errMessage = err.message;
    }  
  );
}
}
