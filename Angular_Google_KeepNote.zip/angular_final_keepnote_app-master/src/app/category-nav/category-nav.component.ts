import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-category-nav',
  templateUrl: './category-nav.component.html',
  styleUrls: ['./category-nav.component.css']
})
export class CategoryNavComponent implements OnInit {

  constructor(private categoryService:CategoryService) { 
    this.categoryService.fetchCategoriesFromServer();
  }

  ngOnInit() {
  }

}
