import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { UserService } from '../services/user.service';
import { User } from '../user';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
  options: FormGroup;
  hide=true;
  user: User = new User();
  userId = new FormControl();
  userPassword = new FormControl();
  firstName= new FormControl();
  lastName= new FormControl();
  mobileNo=new FormControl();
  bearerToken: any;
  submitMessage: String;
  formValidation:String;
  regMessage:string;
  registerForm;

  constructor(private userservice: UserService,
    private routerService: RouterService, private authservice: AuthenticationService,fb:FormBuilder) { 
    this.options = fb.group({
      mobileNo: [10, Validators.length],
    });
  }

  ngOnInit() {
    this.registerForm = new FormGroup({ firstName: new FormControl('', [Validators.required]),    
         lastName: new FormControl('', [Validators.required]),
        userId: new FormControl('', [Validators.required]),
        userPassword: new FormControl('', [Validators.required, Validators.minLength(4)]),
        mobileNo: new FormControl('', [Validators.required])
    });

  }

  get registerF() { return this.registerForm.controls; }

  doRegister() {
    let user=new User();
  //  if(this.user!=null) {
     this.userservice.doRegister(this.registerForm.value).subscribe(response=>{
      //console.log("Sign UP success");
     alert(" User is Registered Successfully. You can Login..");
      this.routerService.routeToLogin();   
    }
    ,error => {
      if(error.status == 409){
        this.submitMessage = 'User Already Exists';
      }
      else{
        console.log(" submit register msg "+this.submitMessage );
      }  
    })
  }
}
