import { Component, OnInit } from '@angular/core';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-note-nav',
  templateUrl: './note-nav.component.html',
  styleUrls: ['./note-nav.component.css']
})
export class NoteNavComponent implements OnInit {

  constructor(private noteservice:NotesService) { 

    this.noteservice.fetchNotesFromServer();
  }

  ngOnInit() {
  }

}
