import { Component, OnInit } from '@angular/core';
import { ReminderService } from '../services/reminder.service';

@Component({
  selector: 'app-reminder-nav',
  templateUrl: './reminder-nav.component.html',
  styleUrls: ['./reminder-nav.component.css']
})
export class ReminderNavComponent implements OnInit {

  constructor(private reminderService:ReminderService) { 
    this.reminderService.fetchRemindersFromServer();
  }

  ngOnInit() {
  }

}
