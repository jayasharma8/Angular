export class NoteCategory {
  categoryId: string;
  categoryName: string;
  }