import { Component, OnInit, Input } from '@angular/core';
import { Note } from '../note';
import { RouterService } from '../services/router.service';
import {NotesService} from '../services/notes.service';
import { MatDialog } from '@angular/material';
import {AddNoteCategoryComponent} from '../add-note-category/add-note-category.component';
import { AddNoteReminderComponent } from '../add-note-reminder/add-note-reminder.component';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {

  errMessage: string;

  @Input() note: Note;
  constructor(private dialog: MatDialog,private routerService: RouterService, private notesService: NotesService) { }

  ngOnInit() {
  }

  openEditView() {
    console.log(this.note.noteId);
    this.routerService.routeToEditNoteView(this.note.noteId);
  }
  openNoteCategoryView(note){
    console.log(" note --"+ note);
    this.dialog.open(AddNoteCategoryComponent, {
      width:'350px',
      data: {
        noteInfo : note
      }
    }).afterClosed().subscribe(result => {
      this.routerService.routeToNoteNav();
    });
  }

  openNoteReminderView(note){
      console.log(" openNoteReminderView  ");
      this.dialog.open(AddNoteReminderComponent, {
        width:'350px',
        data: {
          reminderInfo : note
        }
      }).afterClosed().subscribe(result => {
        this.routerService.routeToNoteNav();
      });
  }
deleteNote() {
  this.notesService.deleteNote(this.note).subscribe(
    deletedNote => {
      const arrayIdx:number = this.notesService.notes.findIndex( noteValue => noteValue.noteId === this.note.noteId);
      console.log("arrayIdx "+arrayIdx);
      this.notesService.notes.splice(arrayIdx,1);
     this.notesService.notesSubject.next(this.notesService.notes);
    },
    err => {
     this.errMessage = err.message;
    }  
  );
}

}
