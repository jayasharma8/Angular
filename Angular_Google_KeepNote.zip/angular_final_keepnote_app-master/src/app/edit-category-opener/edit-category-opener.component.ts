import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { EditCategoryViewComponent } from '../edit-category-view/edit-category-view.component';
import {ActivatedRoute} from '@angular/router';
import {RouterService} from '../services/router.service';

@Component({
  selector: 'app-edit-category-opener',
  templateUrl: './edit-category-opener.component.html',
  styleUrls: ['./edit-category-opener.component.css']
})
export class EditCategoryOpenerComponent {

  // constructor() { }

  constructor(private dialog: MatDialog, private activateRoute: ActivatedRoute, private routerService: RouterService) {

    const categoryId = +this.activateRoute.snapshot.paramMap.get('categoryId');
    console.log('this is the card index : ' + categoryId);
    this.dialog.open(EditCategoryViewComponent, {
      data: {
        categoryId : categoryId
      }
    }).afterClosed().subscribe(result => {
      this.routerService.routeBack();
    });
   }
}
