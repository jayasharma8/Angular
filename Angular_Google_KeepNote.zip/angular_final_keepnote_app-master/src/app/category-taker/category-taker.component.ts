import { Component, OnInit } from '@angular/core';
import { Category } from '../category';

import {CategoryService} from '../services/category.service';

@Component({
  selector: 'app-category-taker',
  templateUrl: './category-taker.component.html',
  styleUrls: ['./category-taker.component.css']
})
export class CategoryTakerComponent implements OnInit {

  category: Category = new Category(); 
  categories: Array<Category> = []; 
  errMessage: String;

  constructor(private categoryService: CategoryService) {
  }
  ngOnInit() {
  }

  takeCategory() {
    if (this.category.categoryName !== '' && this.category.categoryDescription !== '') {
      let catLength=this.categoryService.userCategory.length;
      this.category.categoryId=(catLength+1).toString();
      this.categoryService.userCategory.push(this.category);
      this.categoryService.categories.push(this.category);
      this.categoryService.addCategory(this.category).subscribe( 
        data => {
		this.category = new Category();
},
        err => {
          if (err.status === 404) {
            this.errMessage = `Http failure response for ${err.url}: 404 Not Found`;
          } else {
            this.errMessage = 'Unexpected error occurred:' + err.error.message;
          }
          const index: number = this.categories.findIndex( category => category.categoryDescription === this.category.categoryDescription);
          this.categories.splice(index, 1);
        }
      );
      console.log(this.categories);
    } else {
        this.errMessage = 'Title and Text both are required fields';
    }
  }


}
