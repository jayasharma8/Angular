import { Component, OnInit } from '@angular/core';
import {Reminder} from '../reminder';
import { ReminderService } from '../services/reminder.service';

@Component({
  selector: 'app-reminder-taker',
  templateUrl: './reminder-taker.component.html',
  styleUrls: ['./reminder-taker.component.css']
})
export class ReminderTakerComponent implements OnInit {

  reminder: Reminder = new Reminder(); 
  reminders: Array<Reminder> = []; 
  errMessage: String;

  constructor(private reminderService: ReminderService) {
  }
  ngOnInit() {
  }

  takeReminder() {
    if (this.reminder.reminderName !== '' && this.reminder.reminderDescription !== '') {
      let remLength=this.reminderService.userReminder.length;
      console.log(" length  == " + remLength);
      this.reminder.reminderId=(remLength+1).toString();
      this.reminderService.userReminder.push(this.reminder);
      this.reminderService.reminders.push(this.reminder);
      this.reminderService.addReminder(this.reminder).subscribe( 
        data => {
		this.reminder = new Reminder();
},
        err => {
          if (err.status === 404) {
            this.errMessage = `Http failure response for ${err.url}: 404 Not Found`;
          } else {
            this.errMessage = 'Unexpected error occurred:' + err.error.message;
          }
          const index: number = this.reminders.findIndex( reminder => reminder.reminderDescription === this.reminder.reminderDescription);
          this.reminders.splice(index, 1);
        }
      );
      console.log(this.reminders);
    } else {
        this.errMessage = 'Title and Text both are required fields';
    }
  }

}
