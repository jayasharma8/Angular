import { Component, OnInit } from '@angular/core';

import {Note} from '../note';

import {NotesService} from '../services/notes.service';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {
  note: Note = new Note(); 
  notes: Array<Note> = []; 
  errMessage: String;

  constructor(private notesService: NotesService) {
  }

  ngOnInit() {
  }

  takeNotes() {
    if (this.note.noteTitle !== '' && this.note.noteContent !== '') {
      let noteLength=this.notesService.notes.length;
      this.note.noteId=noteLength+1;
      this.notesService.notes.push(this.note);
      this.notesService.addNote(this.note).subscribe(
        data => {
    this.note = new Note();
   // this.notesService.fetchNotesFromServer();
},
        err => {
          if (err.status === 404) {
            this.errMessage = `Http failure response for ${err.url}: 404 Not Found`;
          } else {
            this.errMessage = 'Unexpected error occurred:' + err.error.message;
          }
          const index: number = this.notes.findIndex( note => note.noteTitle === this.note.noteTitle);
          this.notes.splice(index, 1);
        }
      );
      console.log(this.notes);
    } else {
        this.errMessage = 'Title and Text both are required fields';
    }
  }


}
