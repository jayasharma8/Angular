import { Component, OnInit,Input } from '@angular/core';
import { Reminder } from '../reminder';
import { RouterService } from '../services/router.service';
import {ReminderService} from '../services/reminder.service';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {

  errMessage: string;

  @Input() reminder: Reminder;
  constructor(private routerService: RouterService, private reminderService: ReminderService) { }

  ngOnInit() {
  }

  openEditReminderView() {
    console.log(this.reminder.reminderId);
    this.routerService.routeToEditReminderView(this.reminder.reminderId);
  }

  deleteReminder() {
  this.reminderService.deleteReminder(this.reminder).subscribe(
    deletedReminder => {
      const arrayIdx:number = this.reminderService.reminders.findIndex( reminderValue => reminderValue.reminderId === this.reminder.reminderId);
      console.log("arrayIdx "+arrayIdx);
      this.reminderService.reminders.splice(arrayIdx,1);
     this.reminderService.reminderSubject.next(this.reminderService.reminders);
    },
    err => {
     this.errMessage = err.message;
    }  
  );
}

}
