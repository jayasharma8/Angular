import { Component, OnInit,Inject } from '@angular/core';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Reminder } from '../reminder';

import { RouterService } from '../services/router.service';
import { ReminderService } from '../services/reminder.service';

@Component({
  selector: 'app-edit-reminder-view',
  templateUrl: './edit-reminder-view.component.html',
  styleUrls: ['./edit-reminder-view.component.css']
})
export class EditReminderViewComponent implements OnInit {

  reminder:Reminder;
  //states: Array<string> = ['not-started', 'started', 'completed'];
  errMessage: string;

  //constructor() { }
  constructor(private matDialogRef: MatDialogRef<EditReminderViewComponent>,
    private routeService: RouterService,
    private reminderService: ReminderService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private location: Location) { }

  ngOnInit() {
    console.log('Edit reminder ID ' + this.data.reminderId);
    this.reminder = this.reminderService.getReminderById(this.data.reminderId);
  }

  onSaveReminder() {
    this.reminderService.editReminder(this.reminder).subscribe(
      editedReminder => {
      this.matDialogRef.close();
      },
      err => {
       this.errMessage = err.message;
        
      }  
    );
  }

}
